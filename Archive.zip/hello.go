package main

import (
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"path/filepath"
	"strings"
)

func get(path string) string {
	content, _ := http.Get(path)
	if content.StatusCode == 200 {
		fmt.Println("--- FOUND --- :", path)
		return path
	}
	return ""
}

func loadListFile(path string) string {
	b, err := ioutil.ReadFile(path)
	if err != nil { fmt.Print(err) }
	return string(b)
}

func getAllFiles() []string {
	var files []string

	root := "dict/"
	err := filepath.Walk(root, func(path string, info os.FileInfo, err error) error {
		files = append(files, path)
		return nil
	})
	if err != nil {
		panic(err)
	}
	return files
}

func main() {
	baseURL := "https://tomu.fr/"
	correctPath := make([]string, 10, 50)
	files := getAllFiles()

	for _, filename := range files {
		list := loadListFile(filename)
		for _, element := range strings.Split(list, "\n") {
			correct := get(baseURL + element)
			if correct != "" { correctPath = append(correctPath, correct) }
		}
	}
	fmt.Println("FINISH --- : ", correctPath)
}

